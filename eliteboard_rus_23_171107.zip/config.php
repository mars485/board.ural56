<?php
$db_host  = 'localhost';
$db_user  = '';
$db_name  = '';
$db_pass  = '';
$db_pref  = 'eboard_';
$path = str_replace('index.php', '', $_SERVER['PHP_SELF']);
$host = $_SERVER['HTTP_HOST'];
$fullpath = dirname(__FILE__) . '/';
$install = true;
?>