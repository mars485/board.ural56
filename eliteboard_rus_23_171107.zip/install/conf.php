<?php
$conf['balance'] = 0;
$conf['convert_images'] = true;
$conf['copy_images'] = false;

$conf['update'] = array();
$conf['update'][] = 'cat';
$conf['update'][] = 'region';
$conf['update'][] = 'users';
$conf['update'][] = 'db';
$conf['update'][] = 'blocks';
$conf['update'][] = 'modules';
$conf['update'][] = 'settings';
$conf['update'][] = 'nav';
?>